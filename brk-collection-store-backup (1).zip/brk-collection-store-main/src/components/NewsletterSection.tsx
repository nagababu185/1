import { motion } from "framer-motion";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const NewsletterSection = () => {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Welcome to the BRK Collections fam 🔥");
    setEmail("");
  };

  return (
    <section className="py-24 px-6 border-t border-border">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="max-w-xl mx-auto text-center"
      >
        <h2 className="font-display text-5xl text-foreground mb-4">JOIN BRK COLLECTIONS</h2>
        <p className="text-muted-foreground mb-8">
          Get early access to drops, exclusive offers, and behind-the-scenes content.
        </p>
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            type="email"
            required
            className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
          />
          <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90 font-display tracking-wider px-6">
            SUBSCRIBE
          </Button>
        </form>
      </motion.div>
    </section>
  );
};

export default NewsletterSection;
