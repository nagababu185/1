import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="border-t border-border py-12 px-6">
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
      <Link to="/" className="font-display text-2xl tracking-widest text-foreground">
        BRK COLLECTIONS
      </Link>
      <div className="flex gap-6 text-xs uppercase tracking-[0.2em] text-muted-foreground">
        <Link to="/shop" className="hover:text-foreground transition-colors">Shop</Link>
        <Link to="/about" className="hover:text-foreground transition-colors">About</Link>
        <a
          href="https://www.instagram.com/_brk_collections?igsh=czBremU4aTNldWd0&utm_source=qr"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-foreground transition-colors"
        >
          Instagram
        </a>
        <span>TikTok</span>
      </div>
      <p className="text-xs text-muted-foreground">© 2026 BRK COLLECTIONS. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;
