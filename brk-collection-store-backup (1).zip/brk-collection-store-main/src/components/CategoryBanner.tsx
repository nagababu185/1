import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const categories = [
  {
    name: "T-Shirts",
    image: "https://images.unsplash.com/photo-1562157877-818bc0726e07?w=800&h=600&fit=crop",
  },
  {
    name: "Shirts",
    image: "https://images.unsplash.com/photo-1520974732400-0df9878bf3f9?w=800&h=600&fit=crop",
  },
  {
    name: "Jeans",
    image: "https://images.unsplash.com/photo-1514995669114-7d935b5308a1?w=800&h=600&fit=crop",
  },
  {
    name: "Hoodies",
    image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=800&h=600&fit=crop",
  },
  {
    name: "Outerwear",
    image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=800&h=600&fit=crop",
  },
  {
    name: "Bottoms",
    image: "https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=800&h=600&fit=crop",
  },
];

const CategoryBanner = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-4">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
            >
              <Link to={`/shop?category=${cat.name}`} className="group relative block overflow-hidden aspect-[4/3] rounded-sm">
                <motion.img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.6 }}
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-500" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <h3 className="font-display text-4xl md:text-5xl text-white tracking-wider">
                    {cat.name.toUpperCase()}
                  </h3>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryBanner;
