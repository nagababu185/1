import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Product } from "@/data/products";
import { formatPrice } from "@/lib/utils";

// category icons for display
const catIcons: Record<string, string> = {
  "T-Shirts": "👕",
  Shirts: "👔",
  Jeans: "👖",
};

interface ProductCardProps {
  product: Product;
  index?: number;
}

const ProductCard = ({ product, index = 0 }: ProductCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
    >
      <Link to={`/product/${product.id}`} className="group block">
        <div className="relative overflow-hidden rounded-sm aspect-[3/4] bg-secondary">
          <motion.img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.08 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          />
          {product.isNew && (
            <span className="absolute top-3 left-3 bg-accent text-accent-foreground text-[10px] font-semibold uppercase tracking-widest px-2 py-1 rounded-sm">
              New
            </span>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </div>
        <div className="mt-3 space-y-1">
          <h3 className="text-sm font-medium text-foreground group-hover:text-accent transition-colors duration-300">
            {product.name}
          </h3>
          <p className="text-[10px] uppercase text-muted-foreground flex items-center gap-1">
            {product.category} {catIcons[product.category] && <span>{catIcons[product.category]}</span>}
          </p>
          <p className="text-sm text-muted-foreground">{formatPrice(product.price)}</p>
        </div>
      </Link>
    </motion.div>
  );
};

export default ProductCard;
