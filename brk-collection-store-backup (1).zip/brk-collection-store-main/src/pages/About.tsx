import { motion } from "framer-motion";

const About = () => (
  <div className="pt-24 pb-16 px-6">
    <div className="max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center mb-16"
      >
        <h1 className="font-display text-7xl md:text-9xl text-foreground mb-6">BRK COLLECTIONS</h1>
        <p className="text-xl text-muted-foreground leading-relaxed">
          Born from the streets. Crafted for the culture.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="space-y-8 text-muted-foreground leading-relaxed"
      >
        <p>
          BRK Collections is more than a clothing brand — it's a movement. We create pieces for those who refuse to blend in, 
          who embrace the space between chaos and calm.
        </p>
        <p>
          Every garment is designed with intention: premium fabrics, considered silhouettes, and a relentless 
          commitment to quality. We believe style shouldn't come at the cost of the planet — that's why we use 
          100% organic and recycled materials wherever possible.
        </p>
        <p>
          Founded in 2024, BRK Collections has quickly become the go-to label for the new generation of streetwear enthusiasts. 
          Our drops are limited, our community is everything.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="mt-16 aspect-video rounded-sm overflow-hidden"
      >
        <img
          src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=1200&h=600&fit=crop"
          alt="BRK Collections brand"
          className="w-full h-full object-cover"
        />
      </motion.div>
    </div>
  </div>
);

export default About;
