import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { products } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/ProductCard";
import { formatPrice } from "@/lib/utils";

const ProductDetail = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const [selectedSize, setSelectedSize] = useState("");
  const { addItem } = useCart();

  if (!product) {
    return (
      <div className="pt-24 px-6 text-center">
        <p className="text-muted-foreground">Product not found</p>
        <Link to="/shop" className="text-accent mt-4 inline-block">Back to shop</Link>
      </div>
    );
  }

  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <div className="pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <Link to="/shop" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8">
          <ArrowLeft size={14} /> Back to shop
        </Link>

        <div className="grid md:grid-cols-2 gap-8 md:gap-16">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="aspect-[3/4] overflow-hidden rounded-sm bg-secondary"
          >
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center"
          >
            {product.isNew && (
              <span className="text-xs uppercase tracking-[0.2em] text-accent mb-2">New Arrival</span>
            )}
            <h1 className="font-display text-5xl md:text-6xl text-foreground mb-2">{product.name.toUpperCase()}</h1>
            <p className="text-2xl font-semibold text-foreground mb-6">{formatPrice(product.price)}</p>
            <p className="text-muted-foreground leading-relaxed mb-8">{product.description}</p>

            <div className="mb-8">
              <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3">Size</p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-12 h-12 flex items-center justify-center text-sm rounded-sm transition-all duration-200 ${
                      selectedSize === size
                        ? "bg-accent text-accent-foreground"
                        : "bg-secondary text-muted-foreground hover:text-foreground hover:border-foreground border border-border"
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <Button
              onClick={() => {
                if (!selectedSize) return;
                addItem(product, selectedSize);
              }}
              disabled={!selectedSize}
              className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-display text-lg tracking-wider h-14 disabled:opacity-30"
            >
              {selectedSize ? "ADD TO BAG" : "SELECT A SIZE"}
            </Button>
          </motion.div>
        </div>

        {related.length > 0 && (
          <div className="mt-24">
            <h2 className="font-display text-4xl text-foreground text-center mb-12">YOU MIGHT ALSO LIKE</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {related.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
