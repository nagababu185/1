import HeroSection from "@/components/HeroSection";
import FeaturedSection from "@/components/FeaturedSection";
import CategoryBanner from "@/components/CategoryBanner";
import NewsletterSection from "@/components/NewsletterSection";

const Index = () => {
  return (
    <div>
      <HeroSection />
      <FeaturedSection />
      <CategoryBanner />
      <NewsletterSection />
    </div>
  );
};

export default Index;
