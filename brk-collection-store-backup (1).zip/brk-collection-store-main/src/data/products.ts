export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  description: string;
  sizes: string[];
  isNew?: boolean;
  isFeatured?: boolean;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Shadow Oversized Tee",
    price: 59,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop",
    category: "T-Shirts",
    description: "Premium heavyweight cotton with a relaxed oversized fit. Features a subtle embossed logo on the chest.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    isNew: true,
    isFeatured: true,
  },
  {
    id: "2",
    name: "Midnight Cargo Pants",
    price: 120,
    image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&h=800&fit=crop",
    category: "Bottoms",
    description: "Utility-inspired cargo pants with adjustable ankle cuffs and multiple pockets.",
    sizes: ["28", "30", "32", "34", "36"],
    isFeatured: true,
  },
  {
    id: "3",
    name: "Vortex Hoodie",
    price: 145,
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop",
    category: "Hoodies",
    description: "Ultra-soft French terry hoodie with a kangaroo pocket and dropped shoulders.",
    sizes: ["S", "M", "L", "XL"],
    isNew: true,
    isFeatured: true,
  },
  {
    id: "4",
    name: "Stealth Bomber Jacket",
    price: 220,
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&h=800&fit=crop",
    category: "Outerwear",
    description: "Nylon bomber jacket with ribbed cuffs and a matte finish.",
    sizes: ["S", "M", "L", "XL"],
    isFeatured: true,
  },
  {
    id: "5",
    name: "Core Slim Joggers",
    price: 89,
    image: "https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=600&h=800&fit=crop",
    category: "Bottoms",
    description: "Tapered joggers with zippered pockets and elastic waistband.",
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "6",
    name: "BRK Collections Graphic Tee",
    price: 49,
    image: "https://images.unsplash.com/photo-1503341504253-dff4855a1dfc?w=600&h=800&fit=crop",
    category: "T-Shirts",
    description: "Screen-printed graphic tee on 100% organic cotton.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    isNew: true,
  },
  {
    id: "7",
    name: "Urban Crossbody Bag",
    price: 75,
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&h=800&fit=crop",
    category: "Accessories",
    description: "Compact crossbody with adjustable strap and water-resistant shell.",
    sizes: ["ONE SIZE"],
  },
  {
    id: "8",
    name: "Eclipse Windbreaker",
    price: 165,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&h=800&fit=crop",
    category: "Outerwear",
    description: "Lightweight windbreaker with reflective details and hidden hood.",
    sizes: ["S", "M", "L", "XL"],
    isNew: true,
  },
  {
    id: "9",
    name: "Camo Button-Up Shirt",
    price: 99,
    image: "https://images.unsplash.com/photo-1562157877-818bc0726e07?w=600&h=800&fit=crop",
    category: "Shirts",
    description: "Relaxed-fit camo shirt with chest pockets and button closures.",
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "10",
    name: "Slim Denim Jeans",
    price: 119,
    image: "https://images.unsplash.com/photo-1514995669114-7d935b5308a1?w=600&h=800&fit=crop",
    category: "Jeans",
    description: "Classic slim-fit denim with slight stretch for comfort.",
    sizes: ["28", "30", "32", "34", "36"],
  },
];

export const categories = [
  "All",
  "T-Shirts",
  "Shirts",
  "Jeans",
  "Hoodies",
  "Bottoms",
  "Outerwear",
  "Accessories",
];
